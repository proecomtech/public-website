<?php
$PAGE_TITLE = 'Contact';
require_once __DIR__ . '/includes/icons.php';

// Pull any status passed back from the form handler
$status = $_GET['sent'] ?? '';
include __DIR__ . '/includes/header.php';
?>
<a id="top"></a>

<section class="page-hero">
    <div class="container reveal">
        <p class="eyebrow">Contact</p>
        <h1>Let&rsquo;s talk about your project</h1>
        <p class="lead">Fill out the form and we will get back to you within one business day.</p>
    </div>
</section>

<section class="section">
    <div class="container contact-grid">
        <div class="contact-info reveal">
            <h2>Get in touch</h2>
            <ul class="contact-list">
                <li>
                    <span class="contact-ic"><?= icon('support') ?></span>
                    <div><strong>Email</strong><a href="mailto:<?= htmlspecialchars($SITE['email']) ?>"><?= htmlspecialchars($SITE['email']) ?></a></div>
                </li>
                <li>
                    <span class="contact-ic"><?= icon('users') ?></span>
                    <div><strong>Phone</strong><a href="tel:<?= preg_replace('/[^0-9+]/', '', $SITE['phone']) ?>"><?= htmlspecialchars($SITE['phone']) ?></a></div>
                </li>
                <li>
                    <span class="contact-ic"><?= icon('shield') ?></span>
                    <div><strong>Office</strong><span><?= htmlspecialchars($SITE['address']) ?></span></div>
                </li>
            </ul>
        </div>

        <div class="contact-form-wrap reveal">
            <?php if ($status === 'ok'): ?>
                <div class="alert alert--ok">Thanks! Your message has been sent. We&rsquo;ll be in touch soon.</div>
            <?php elseif ($status === 'error'): ?>
                <div class="alert alert--err">Something went wrong. Please check the form and try again.</div>
            <?php endif; ?>

            <form action="process-contact.php" method="POST" class="contact-form" novalidate>
                <div class="field">
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="field-row">
                    <div class="field">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="field">
                        <label for="phone">Phone (optional)</label>
                        <input type="tel" id="phone" name="phone">
                    </div>
                </div>
                <div class="field">
                    <label for="subject">Subject</label>
                    <input type="text" id="subject" name="subject">
                </div>
                <div class="field">
                    <label for="message">Message</label>
                    <textarea id="message" name="message" rows="5" required></textarea>
                </div>
                <!-- Honeypot anti-spam field (hidden from humans) -->
                <input type="text" name="website" class="hp" tabindex="-1" autocomplete="off">
                <button type="submit" class="btn btn-primary btn-lg">Send Message</button>
            </form>
        </div>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
