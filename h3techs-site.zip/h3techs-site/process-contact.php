<?php
/**
 * Contact form handler.
 * - Validates input
 * - Blocks spam via honeypot
 * - Emails you the message (configure $TO below)
 * - Also appends to a local log file as a backup
 *
 * NOTE: mail() needs a configured mail server. On local dev it may not send.
 * For production, consider PHPMailer + SMTP for reliable delivery.
 */

require_once __DIR__ . '/includes/config.php';

// Where submissions should be emailed:
$TO = $SITE['email'];

function redirect($status) {
    header('Location: contact.php?sent=' . $status . '#top');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('error');
}

// Honeypot: if filled, it's a bot
if (!empty($_POST['website'])) {
    redirect('ok'); // silently pretend success
}

$name    = trim($_POST['name'] ?? '');
$email   = trim($_POST['email'] ?? '');
$phone   = trim($_POST['phone'] ?? '');
$subject = trim($_POST['subject'] ?? '');
$message = trim($_POST['message'] ?? '');

// Basic validation
if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $message === '') {
    redirect('error');
}

// Build email
$mailSubject = 'New enquiry: ' . ($subject !== '' ? $subject : 'Website contact form');
$body  = "You received a new message from your website.\n\n";
$body .= "Name:    $name\n";
$body .= "Email:   $email\n";
$body .= "Phone:   " . ($phone !== '' ? $phone : '-') . "\n";
$body .= "Subject: " . ($subject !== '' ? $subject : '-') . "\n\n";
$body .= "Message:\n$message\n";

$headers  = "From: " . $SITE['name'] . " <no-reply@yourdomain.com>\r\n";
$headers .= "Reply-To: $email\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

// Try to send (won't error out the page if mail isn't configured)
@mail($TO, $mailSubject, $body, $headers);

// Backup: append to a log file so you never lose a submission
$logLine = '[' . date('Y-m-d H:i:s') . "] $name <$email> $phone | $subject | "
         . str_replace(["\r", "\n"], ' ', $message) . PHP_EOL;
@file_put_contents(__DIR__ . '/contact-submissions.log', $logLine, FILE_APPEND | LOCK_EX);

redirect('ok');
