<footer class="site-footer">
    <div class="container footer-grid">
        <div class="footer-col footer-about">
            <a href="index.php" class="brand brand--footer">
                <span class="brand-mark">H3</span>
                <span class="brand-name"><?= htmlspecialchars($SITE['name']) ?></span>
            </a>
            <p><?= htmlspecialchars($SITE['description']) ?></p>
            <div class="social">
                <?php if (!empty($SOCIAL['linkedin'])): ?><a href="<?= $SOCIAL['linkedin'] ?>" aria-label="LinkedIn">in</a><?php endif; ?>
                <?php if (!empty($SOCIAL['twitter'])): ?><a href="<?= $SOCIAL['twitter'] ?>" aria-label="Twitter / X">X</a><?php endif; ?>
                <?php if (!empty($SOCIAL['facebook'])): ?><a href="<?= $SOCIAL['facebook'] ?>" aria-label="Facebook">f</a><?php endif; ?>
                <?php if (!empty($SOCIAL['instagram'])): ?><a href="<?= $SOCIAL['instagram'] ?>" aria-label="Instagram">ig</a><?php endif; ?>
            </div>
        </div>

        <div class="footer-col">
            <h4>Company</h4>
            <ul>
                <?php foreach ($NAV as $file => $label): ?>
                    <li><a href="<?= $file ?>"><?= htmlspecialchars($label) ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <div class="footer-col">
            <h4>Services</h4>
            <ul>
                <?php foreach (array_slice($SERVICES, 0, 4) as $s): ?>
                    <li><a href="services.php"><?= htmlspecialchars($s['title']) ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <div class="footer-col">
            <h4>Get in Touch</h4>
            <ul class="footer-contact">
                <li><a href="mailto:<?= htmlspecialchars($SITE['email']) ?>"><?= htmlspecialchars($SITE['email']) ?></a></li>
                <li><a href="tel:<?= preg_replace('/[^0-9+]/', '', $SITE['phone']) ?>"><?= htmlspecialchars($SITE['phone']) ?></a></li>
                <li><?= htmlspecialchars($SITE['address']) ?></li>
            </ul>
        </div>
    </div>

    <div class="footer-bottom">
        <div class="container">
            <p>&copy; <?= $SITE['year'] ?> <?= htmlspecialchars($SITE['name']) ?>. All rights reserved.</p>
        </div>
    </div>
</footer>

<a href="#top" class="back-to-top" id="backToTop" aria-label="Back to top">&uarr;</a>

<script src="assets/js/main.js"></script>
</body>
</html>
