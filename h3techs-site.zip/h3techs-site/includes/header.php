<?php require_once __DIR__ . '/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($SITE['name']) ?> — <?= htmlspecialchars($PAGE_TITLE ?? $SITE['tagline']) ?></title>
    <meta name="description" content="<?= htmlspecialchars($SITE['description']) ?>">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<header class="site-header" id="siteHeader">
    <div class="container header-inner">
        <a href="index.php" class="brand">
            <span class="brand-mark">H3</span>
            <span class="brand-name"><?= htmlspecialchars($SITE['name']) ?></span>
        </a>

        <nav class="nav" id="primaryNav" aria-label="Primary">
            <ul>
                <?php foreach ($NAV as $file => $label): ?>
                    <li>
                        <a href="<?= $file ?>" class="<?= $CURRENT === $file ? 'active' : '' ?>">
                            <?= htmlspecialchars($label) ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
            <a href="contact.php" class="btn btn-primary nav-cta">Get a Quote</a>
        </nav>

        <button class="nav-toggle" id="navToggle" aria-label="Open menu" aria-expanded="false" aria-controls="primaryNav">
            <span></span><span></span><span></span>
        </button>
    </div>
</header>
