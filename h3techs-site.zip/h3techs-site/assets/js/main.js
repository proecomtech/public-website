/* =========================================================
   Site interactions
   ========================================================= */
(function () {
    'use strict';

    /* ---- Mobile nav toggle ---- */
    var toggle = document.getElementById('navToggle');
    var nav = document.getElementById('primaryNav');

    if (toggle && nav) {
        toggle.addEventListener('click', function () {
            var open = nav.classList.toggle('open');
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
        });

        // Close menu when a link is tapped
        nav.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                nav.classList.remove('open');
                toggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    /* ---- Header shadow on scroll ---- */
    var header = document.getElementById('siteHeader');
    var backToTop = document.getElementById('backToTop');

    function onScroll() {
        var y = window.scrollY;
        if (header) header.classList.toggle('scrolled', y > 8);
        if (backToTop) backToTop.classList.toggle('show', y > 500);
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    /* ---- Smooth scroll for back-to-top / anchor links ---- */
    document.querySelectorAll('a[href^="#"]').forEach(function (a) {
        a.addEventListener('click', function (e) {
            var id = a.getAttribute('href');
            if (id === '#' || id.length < 2) return;
            var target = document.querySelector(id);
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });

    /* ---- Scroll reveal animations ---- */
    var revealEls = document.querySelectorAll('.reveal');
    if ('IntersectionObserver' in window && revealEls.length) {
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('in');
                    io.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

        revealEls.forEach(function (el, i) {
            // small stagger for elements in the same row group
            el.style.transitionDelay = (i % 3) * 80 + 'ms';
            io.observe(el);
        });
    } else {
        revealEls.forEach(function (el) { el.classList.add('in'); });
    }

    /* ---- Animated count-up for stats (home page) ---- */
    var counters = document.querySelectorAll('.stat-num[data-count]');
    if ('IntersectionObserver' in window && counters.length) {
        var cio = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (!entry.isIntersecting) return;
                animateCount(entry.target);
                cio.unobserve(entry.target);
            });
        }, { threshold: 0.5 });
        counters.forEach(function (c) { cio.observe(c); });
    }

    function animateCount(el) {
        var raw = el.getAttribute('data-count');           // e.g. "250+", "99%"
        var num = parseFloat(raw.replace(/[^0-9.]/g, ''));
        var suffix = raw.replace(/[0-9.]/g, '');            // "+", "%", etc.
        if (isNaN(num)) return;
        var dur = 1200, start = null;
        function step(ts) {
            if (!start) start = ts;
            var p = Math.min((ts - start) / dur, 1);
            var eased = 1 - Math.pow(1 - p, 3);
            el.textContent = Math.round(num * eased) + suffix;
            if (p < 1) requestAnimationFrame(step);
            else el.textContent = raw;
        }
        requestAnimationFrame(step);
    }

    /* ---- Lightweight contact form validation ---- */
    var form = document.querySelector('.contact-form');
    if (form) {
        form.addEventListener('submit', function (e) {
            var name = form.querySelector('#name');
            var email = form.querySelector('#email');
            var message = form.querySelector('#message');
            var ok = true;

            [name, email, message].forEach(function (f) {
                if (f && !f.value.trim()) { f.style.borderColor = '#ff6058'; ok = false; }
                else if (f) { f.style.borderColor = ''; }
            });

            if (email && email.value && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.value)) {
                email.style.borderColor = '#ff6058';
                ok = false;
            }

            if (!ok) {
                e.preventDefault();
                var firstBad = form.querySelector('[style*="rgb(255"]');
                if (firstBad) firstBad.focus();
            }
        });
    }

})();
