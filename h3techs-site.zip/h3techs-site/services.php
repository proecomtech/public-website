<?php
$PAGE_TITLE = 'Services';
require_once __DIR__ . '/includes/icons.php';
include __DIR__ . '/includes/header.php';
?>
<a id="top"></a>

<section class="page-hero">
    <div class="container reveal">
        <p class="eyebrow">Our Services</p>
        <h1>Everything you need to ship and scale</h1>
        <p class="lead">One team for the full technology lifecycle — strategy, build, launch, and support.</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="cards">
            <?php foreach ($SERVICES as $s): ?>
                <article class="card card--lg reveal">
                    <div class="card-icon"><?= icon($s['icon']) ?></div>
                    <h3><?= htmlspecialchars($s['title']) ?></h3>
                    <p><?= htmlspecialchars($s['text']) ?></p>
                    <a href="contact.php" class="card-link">Get started <span aria-hidden="true">&rarr;</span></a>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section section--soft">
    <div class="container">
        <div class="section-head reveal">
            <p class="eyebrow">How It Works</p>
            <h2>A simple, proven process</h2>
            <p class="section-sub">Clear steps so you always know where your project stands.</p>
        </div>
        <ol class="process">
            <li class="reveal"><span class="process-num">01</span><h3>Discover</h3><p>We learn your goals, users, and constraints before writing a line of code.</p></li>
            <li class="reveal"><span class="process-num">02</span><h3>Plan</h3><p>A clear scope, timeline, and estimate — no surprises down the line.</p></li>
            <li class="reveal"><span class="process-num">03</span><h3>Build</h3><p>We develop in short cycles with regular demos so you see progress early.</p></li>
            <li class="reveal"><span class="process-num">04</span><h3>Support</h3><p>After launch we monitor, maintain, and improve what we shipped.</p></li>
        </ol>
    </div>
</section>

<section class="cta-band">
    <div class="container cta-inner reveal">
        <div>
            <h2>Not sure where to start?</h2>
            <p>Book a free consultation and we will point you in the right direction.</p>
        </div>
        <a href="contact.php" class="btn btn-light btn-lg">Talk to an Expert</a>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
