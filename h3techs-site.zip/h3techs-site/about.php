<?php
$PAGE_TITLE = 'About Us';
require_once __DIR__ . '/includes/icons.php';
include __DIR__ . '/includes/header.php';
?>
<a id="top"></a>

<section class="page-hero">
    <div class="container reveal">
        <p class="eyebrow">About <?= htmlspecialchars($SITE['name']) ?></p>
        <h1>We help businesses use technology with confidence</h1>
        <p class="lead">For over a decade we have partnered with startups and established companies to design, build, and support software that actually moves the needle.</p>
    </div>
</section>

<section class="section">
    <div class="container two-col">
        <div class="reveal">
            <h2>Our story</h2>
            <p>What started as a small team of engineers has grown into a full-service technology partner. We have always believed the same thing: good technology should make work simpler, not harder.</p>
            <p>Today we work across software development, cloud, security, data, and IT staffing — but the goal has never changed. We want to be the team you call when something matters.</p>
        </div>
        <div class="reveal">
            <h2>Our mission</h2>
            <p>To deliver technology that is reliable, secure, and built around real people. We measure success by your results, not by hours billed.</p>
            <ul class="check-list">
                <li><?= icon('check') ?> Honest advice, even when it is not what you hoped to hear</li>
                <li><?= icon('check') ?> Clean, maintainable work we are proud to put our name on</li>
                <li><?= icon('check') ?> A relationship that lasts beyond a single project</li>
            </ul>
        </div>
    </div>
</section>

<section class="section section--dark">
    <div class="container">
        <div class="stats">
            <?php foreach ($STATS as $st): ?>
                <div class="stat reveal">
                    <span class="stat-num"><?= htmlspecialchars($st['number']) ?></span>
                    <span class="stat-label"><?= htmlspecialchars($st['label']) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section section--soft">
    <div class="container">
        <div class="section-head reveal">
            <p class="eyebrow">Our Values</p>
            <h2>How we work</h2>
        </div>
        <div class="cards">
            <?php foreach ($WHY as $w): ?>
                <article class="card reveal">
                    <div class="card-icon"><?= icon('check') ?></div>
                    <h3><?= htmlspecialchars($w['title']) ?></h3>
                    <p><?= htmlspecialchars($w['text']) ?></p>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="cta-band">
    <div class="container cta-inner reveal">
        <div>
            <h2>Let&rsquo;s work together</h2>
            <p>We would love to hear what you are building.</p>
        </div>
        <a href="contact.php" class="btn btn-light btn-lg">Contact Us</a>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
